#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "mostrar_contactos.h"
#include <Qfile>
#include <QTextStream>
#include <QMessageBox>
#include <QIntValidator>
#include <QRegularExpression>
#include <QRegularExpressionMatch>
#include "structc.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_actionCrear_triggered()
{


}


void MainWindow::on_actionActualizar_triggered()
{
    Actualizar *actualizarVentana = new Actualizar(this);
    actualizarVentana->setModal(true);
    actualizarVentana->show();
}



void MainWindow::on_actionEliminar_triggered()
{
    Eliminar *eliminarContacto= new Eliminar(this);
    eliminarContacto->show();



}


void MainWindow::on_btnGuardar_clicked()
{
    c.nombre=ui->txtNombre->text();
    c.apellido=ui->txtApellido->text();
    c.nickname=ui->txtApodo->text();
    QString celular_texto=ui->txtCelular->text();
    c.celular=celular_texto.toInt();
    c.correo=ui->txtCorreo->text();
    c.direccion=ui->txtDireccion->text();
    QLocale locale(QLocale::Spanish,QLocale::Spain);
    c.cumpl=locale.toString(ui->dateEdit->date(),"dd MMMM yyyy");

//Validar entrada de nombre y apellido
    static const QRegularExpression regex("^[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+$");
    QRegularExpressionMatch match=regex.match(c.nombre);
    QRegularExpressionMatch match_apellido=regex.match(c.apellido);
//Validar correo con un arroba y un .com
    static const QRegularExpression regexCorreo("^[^\\s@]+@[^\\s@]+\\.com$");
    QRegularExpressionMatch match_correo=regexCorreo.match(c.correo);
//Validar que no ingresen letras en el apartado "telefono"
    static const QRegularExpression regexNum("^0\\d+$");
    QRegularExpressionMatch match_telefono=regexNum.match(celular_texto);
//Limite de digitos ingresados en el campo "celular"
    static const QRegularExpression regex_digitos("^\\d{0,10}$");
    QRegularExpressionMatch match_digitos=regex_digitos.match(celular_texto);

    if(c.nombre.isEmpty() || c.apellido.isEmpty() || c.nickname.isEmpty() ||
        celular_texto.isEmpty() || c.correo.isEmpty() || c.direccion.isEmpty() || c.cumpl.isEmpty())
    {
        QMessageBox::warning(this, "ERROR","Por favor ingrese los datos correctamente, uno o mas campos vacios");

    }else if(!match.hasMatch() or !match_apellido.hasMatch()){
        QMessageBox::warning(this,"ERROR","El nombre y el apellido no deben contener caracteres especiales");
        ui->txtNombre->clear();
        ui->txtApellido->clear();
        ui->txtNombre->setFocus();

    }else if(!match_correo.hasMatch()){
        QMessageBox::warning(this,"ERROR","Correo invalido");
        ui->txtCorreo->clear();
        ui->txtCorreo->setFocus();


    }else if(!match_digitos.hasMatch()){
        QMessageBox::warning(this,"ERROR","El numero de telefono no puede tener mas de 10 digitos");
        ui->txtCelular->clear();
        ui->txtCelular->setFocus();

    }
    else{
        if(!match_telefono.hasMatch()){
            QMessageBox::critical(this,"ERROR","Solo se pueden ingresar numeros");
            ui->txtCelular->clear();
            ui->txtCelular->setFocus();
        }else{
            QFile archivo("lista_contactos.txt");
            if (!archivo.open(QIODevice::Append|QIODevice::Text)){
                QMessageBox::warning(this,"ERROR","No se pudo abrir el archivo");
                return;
            }
            QTextStream guardar(&archivo);
            guardar<<c.nombre<<"|"<<c.apellido<<"|"<<c.nickname<<"|"<<c.celular<<"|"<<c.correo<<"|"<<c.direccion<<"|"<<c.cumpl<<"|"<<"\n";
            archivo.close();
            QMessageBox::information(this,"Exito","Datos guardados correctamente");
            contactos.push_back(c);
            ui->txtNombre->clear();
            ui->txtNombre->setFocus();
            ui->txtApodo->clear();
            ui->txtCelular->clear();
            ui->txtCorreo->clear();
            ui->txtDireccion->clear();
            ui->txtApellido->clear();

        }


    }
}


void MainWindow::on_actionMostrar_Contactos_triggered()
{
    mostrar_contactos *ventana = new mostrar_contactos(this);
    ventana->exec();
}




