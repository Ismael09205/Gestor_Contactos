#include "structc.h"
std::vector<info_contactos> contactos;
info_contactos c;
