#ifndef STRUCTC_H
#define STRUCTC_H
#include <vector>
#include <QString>

struct info_contactos{
    QString nombre;
    QString apellido;
    QString celular;
    QString correo;
    QString direccion;
    QString nickname;
    QString cumpl;
    //QString nombreCompleto;

};

extern std::vector<info_contactos> contactos;
extern info_contactos c;

#endif // STRUCTC_H
