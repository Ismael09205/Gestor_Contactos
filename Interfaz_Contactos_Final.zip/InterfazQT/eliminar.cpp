#include "eliminar.h"
#include "ui_eliminar.h"
#include <QFile>
#include <QTextStream>
#include <QMessageBox>

Eliminar::Eliminar(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Eliminar)
{
    ui->setupUi(this);
    cargarContactos();  // Al iniciar, cargar la lista
}

Eliminar::~Eliminar()
{
    delete ui;
}

// Cargar contactos al QListWidget
void Eliminar::cargarContactos()
{
    QFile archivo("lista_contactos.txt");
    if (!archivo.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "No se pudo abrir el archivo de contactos.");
        return;
    }

    QTextStream in(&archivo);
    while (!in.atEnd()) {
        QString linea = in.readLine();
        QStringList campos = linea.split("|");
        if (campos.size() >= 2) {
            QString nombreCompleto = campos[0] + " " + campos[1];
            ui->lista_con->addItem(nombreCompleto);
        }
    }

    archivo.close();
}

// Eliminar contacto seleccionado
void Eliminar::on_btnEliminar_clicked()
{
    QListWidgetItem *item = ui->lista_con->currentItem();
    if (!item) {
        QMessageBox::information(this, "Atención", "Seleccione un contacto para eliminar.");
        return;
    }

    QString contactoSeleccionado = item->text(); // Nombre Apellido

    QFile archivo("lista_contactos.txt");
    QFile temporal("lista_temporal.txt");

    if (!archivo.open(QIODevice::ReadOnly | QIODevice::Text) ||
        !temporal.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "No se pudo abrir uno de los archivos.");
        return;
    }

    QTextStream in(&archivo);
    QTextStream out(&temporal);
    bool encontrado = false;

    while (!in.atEnd()) {
        QString linea = in.readLine();
        QStringList campos = linea.split("|");
        if (campos.size() >= 2) {
            QString nombreCompleto = campos[0] + " " + campos[1];
            if (nombreCompleto == contactoSeleccionado) {
                encontrado = true;
                continue; // No escribir esta línea
            }
        }
        out << linea << "\n";
    }

    archivo.close();
    temporal.close();

    archivo.remove();
    temporal.rename("lista_contactos.txt");

    if (encontrado) {
        QMessageBox::information(this, "Eliminado", "El contacto fue eliminado correctamente.");
        delete item; // quitar de la lista
    } else {
        QMessageBox::warning(this, "No encontrado", "No se encontró el contacto a eliminar.");
    }
}
