#include "actualizar.h"
#include "ui_actualizar.h"
#include <QMessageBox>
#include <QTextStream>
#include <QFile>
#include <QDebug>
#include <QRegularExpression>

Actualizar::Actualizar(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Actualizar),
    contactoActualIndex(-1)
{
    ui->setupUi(this);


    ui->tableViewContactos->setColumnCount(7);
    QStringList headers = {"Nombre", "Apellido", "Celular", "Correo", "Direccion","NickName","Cumpleaños"};
    ui->tableViewContactos->setHorizontalHeaderLabels(headers);
    ui->tableViewContactos->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableViewContactos->setSelectionMode(QAbstractItemView::SingleSelection);


    connect(ui->btnSeleccionar, &QPushButton::clicked, this, &Actualizar::seleccionarContacto);
    connect(ui->btnGuardar, &QPushButton::clicked, this, &Actualizar::guardarCambios);
    connect(ui->btnCancelar, &QPushButton::clicked, this, &Actualizar::cancelarEdicion);


    ui->frameEdicion->setVisible(false);


    cargarContactos();
}

Actualizar::~Actualizar()
{
    delete ui;
}

void Actualizar::cargarContactos()
{
    QFile file("lista_contactos.txt");
    if (!file.exists()) {
        QMessageBox::information(this, "Información", "No hay contactos registrados.");
        return;
    }
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text) || file.size() == 0) {
        qDebug() << "Error al abrir lista_contactos.txt:" << file.errorString();
        QMessageBox::warning(this, "Error", "No se pudo abrir el archivo de contactos.");
        return;
    }

    QTextStream in(&file);
    ui->tableViewContactos->setRowCount(0);
    int rowCount = 0;
    while (!in.atEnd()) {
        QString line = in.readLine().trimmed();
        if (line.isEmpty()) continue;

        QStringList datos = line.split("|");
        if (datos.size() == 7) {
            ui->tableViewContactos->insertRow(rowCount);
            for (int i = 0; i < 7; ++i) {
                ui->tableViewContactos->setItem(rowCount, i, new QTableWidgetItem(datos[i].trimmed()));
            }
            rowCount++;
        }
    }
    file.close();
    ui->tableViewContactos->resizeColumnsToContents();
}

void Actualizar::seleccionarContacto()
{
    if (ui->tableViewContactos->currentRow() < 0) {
        QMessageBox::warning(this, "Error", "Seleccione un contacto para actualizar.");
        return;
    }

    contactoActualIndex = ui->tableViewContactos->currentRow();
    qDebug() << "Contacto seleccionado en fila:" << contactoActualIndex;

    if (QMessageBox::question(this, "Confirmar", "¿Desea actualizar el contacto seleccionado?",
                              QMessageBox::Ok | QMessageBox::Cancel) == QMessageBox::Ok) {
        mostrarFormularioEdicion();
    }
}

void Actualizar::mostrarFormularioEdicion()
{
    if (contactoActualIndex < 0 || contactoActualIndex >= ui->tableViewContactos->rowCount()) {
        qDebug() << "Índice de contacto inválido:" << contactoActualIndex;
        return;
    }

    ui->lineEditNombre->setText(ui->tableViewContactos->item(contactoActualIndex, 0)->text());
    ui->lineEditApellido->setText(ui->tableViewContactos->item(contactoActualIndex, 1)->text());
    ui->lineEditCelular->setText(ui->tableViewContactos->item(contactoActualIndex, 2)->text());
    ui->lineEditCorreo->setText(ui->tableViewContactos->item(contactoActualIndex, 3)->text());
    ui->lineEditDireccion->setText(ui->tableViewContactos->item(contactoActualIndex, 4)->text());
    ui->lineEditApodo->setText(ui->tableViewContactos->item(contactoActualIndex, 5)->text());
    ui->dateEditCumpleanos->setDate(QDate::fromString(ui->tableViewContactos->item(contactoActualIndex, 6)->text(), "yyyy-MM-dd"));

    ui->frameEdicion->setVisible(true);
}

void Actualizar::guardarCambios()
{
    if (contactoActualIndex == -1) {
        QMessageBox::warning(this, "Error", "No se ha seleccionado un contacto.");
        return;
    }

    QString nombre = ui->lineEditNombre->text().trimmed();
    if (nombre.isEmpty()) {
        QMessageBox::warning(this, "Error", "El nombre es obligatorio.");
        return;
    }

    QString correo = ui->lineEditCorreo->text().trimmed();
    const static QRegularExpression regex("^[^\\s@]+@[^\\s@]+\\.com$");
    if (!correo.isEmpty() and !regex.match(correo).hasMatch()) {
        QMessageBox::warning(this, "Error", "El correo electrónico no es válido.");
        return;
    }

    if (QMessageBox::question(this, "Confirmar", "¿Desea guardar los cambios?",
                              QMessageBox::Ok | QMessageBox::Cancel) != QMessageBox::Ok) {
        return;
    }

    ui->tableViewContactos->item(contactoActualIndex, 0)->setText(nombre);
    ui->tableViewContactos->item(contactoActualIndex, 1)->setText(ui->lineEditApellido->text());
    ui->tableViewContactos->item(contactoActualIndex, 2)->setText(ui->lineEditCelular->text());
    ui->tableViewContactos->item(contactoActualIndex, 3)->setText(ui->lineEditCorreo->text());
    ui->tableViewContactos->item(contactoActualIndex, 4)->setText(ui->lineEditDireccion->text());
    ui->tableViewContactos->item(contactoActualIndex, 5)->setText(ui->lineEditApodo->text());
    ui->tableViewContactos->item(contactoActualIndex, 6)->setText(ui->dateEditCumpleanos->date().toString("yyyy-MM-dd"));

    guardarContactos();
    QMessageBox::information(this, "Éxito", "Contacto actualizado correctamente.");
    ui->frameEdicion->setVisible(false);
    contactoActualIndex = -1;
}

void Actualizar::cancelarEdicion()
{
    ui->frameEdicion->setVisible(false);
    contactoActualIndex = -1;
}

void Actualizar::guardarContactos()
{
    QFile file("lista_contactos.txt");
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        qDebug() << "Error al guardar:" << file.errorString();
        QMessageBox::warning(this, "Error", "No se pudo guardar el archivo.");
        return;
    }

    QTextStream out(&file);
    for (int i = 0; i < ui->tableViewContactos->rowCount(); ++i) {
        QStringList campos;
        for (int j = 0; j < 7; ++j) {
            campos << ui->tableViewContactos->item(i, j)->text();
        }
        out << campos.join("|") << "\n";
    }
    file.close();
}
