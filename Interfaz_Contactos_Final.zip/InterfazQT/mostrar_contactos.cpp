#include "mostrar_contactos.h"
#include "ui_mostrar_contactos.h"
#include "structc.h"
#include <QFile>
#include <QTextStream>
#include <QTextEdit>
#include <QStringList>
#include <QTableWidgetItem>
#include <QMessageBox>


    mostrar_contactos::mostrar_contactos(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::mostrar_contactos)
{

    ui->setupUi(this);
    setWindowTitle("Mostrar todos los contactos");

    ui->tablaContactos->setColumnCount(7);
    QStringList encabezados = {"Nombre", "Apellido", "Teléfono", "Correo", "Dirección", "Apodo", "Cumpleaños"};
    ui->tablaContactos->setHorizontalHeaderLabels(encabezados);


    ui->tablaContactos->setRowCount(0);


    for (size_t i = 0; i < contactos.size(); ++i) {
        ui->tablaContactos->insertRow(i);

        ui->tablaContactos->setItem(i, 0, new QTableWidgetItem(contactos[i].nombre));
        ui->tablaContactos->setItem(i, 1, new QTableWidgetItem(contactos[i].apellido));
        ui->tablaContactos->setItem(i, 2, new QTableWidgetItem(contactos[i].celular));
        ui->tablaContactos->setItem(i, 3, new QTableWidgetItem(contactos[i].correo));
        ui->tablaContactos->setItem(i, 4, new QTableWidgetItem(contactos[i].direccion));
        ui->tablaContactos->setItem(i, 5, new QTableWidgetItem(contactos[i].nickname));
        ui->tablaContactos->setItem(i, 6, new QTableWidgetItem(contactos[i].cumpl));
    }


    ui->tablaContactos->resizeColumnsToContents();
}



void mostrar_contactos::on_pushButton_clicked()
{
    this->close();
}

mostrar_contactos::~mostrar_contactos() {
    delete ui;
}


