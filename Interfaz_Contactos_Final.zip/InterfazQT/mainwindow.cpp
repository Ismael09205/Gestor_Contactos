#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "mostrar_contactos.h"
#include <Qfile>
#include <QTextStream>
#include <QMessageBox>
#include <QIntValidator>
#include <QRegularExpression>
#include <QRegularExpressionMatch>
#include "structc.h"

extern std::vector<info_contactos> contactos;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{

    ui->setupUi(this);
    setWindowTitle("Gestor de Contactos");
    cargarContactos();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_actionCrear_triggered()
{


}


void MainWindow::on_actionActualizar_triggered()
{
    Actualizar *actualizarVentana = new Actualizar(this);
    actualizarVentana->setModal(true);
    actualizarVentana->show();
}



void MainWindow::on_actionEliminar_triggered()
{
    Eliminar *eliminarContacto= new Eliminar(this);
    eliminarContacto->show();



}


void MainWindow::on_btnGuardar_clicked()
{

    c.nombre=ui->txtNombre->text();
    c.apellido=ui->txtApellido->text();
    c.nickname=ui->txtApodo->text();
    //QString celular_texto=ui->txtCelular->text();
    c.celular=ui->txtCelular->text();
    c.correo=ui->txtCorreo->text();
    c.direccion=ui->txtDireccion->text();
    QLocale locale(QLocale::Spanish,QLocale::Spain);
    c.cumpl=locale.toString(ui->dateEdit->date(),"dd MMMM yyyy");

//Validar entrada de nombre y apellido
    static const QRegularExpression regex("^[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+$");
    QRegularExpressionMatch match=regex.match(c.nombre);
    QRegularExpressionMatch match_apellido=regex.match(c.apellido);
//Validar correo con un arroba y un .com
    static const QRegularExpression regexCorreo("^[^\\s@]+@[^\\s@]+\\.com$");
    QRegularExpressionMatch match_correo=regexCorreo.match(c.correo);
//Validar que no ingresen letras en el apartado "telefono"
    static const QRegularExpression regexNum("^0\\d+$");
    QRegularExpressionMatch match_telefono=regexNum.match(c.celular);
//Limite de digitos ingresados en el campo "celular"
    static const QRegularExpression regex_digitos("^\\d{0,10}$");
    QRegularExpressionMatch match_digitos=regex_digitos.match(c.celular);

    if(c.nombre.isEmpty() || c.apellido.isEmpty() || c.nickname.isEmpty() ||
        c.celular.isEmpty() || c.correo.isEmpty() || c.direccion.isEmpty() || c.cumpl.isEmpty())
    {
        QMessageBox::warning(this, "ERROR","Por favor ingrese los datos correctamente, uno o mas campos vacios");

    }else if(!match.hasMatch() or !match_apellido.hasMatch()){
        QMessageBox::warning(this,"ERROR","El nombre y el apellido no deben contener caracteres especiales");
        ui->txtNombre->clear();
        ui->txtApellido->clear();
        ui->txtNombre->setFocus();

    }else if(!match_correo.hasMatch()){
        QMessageBox::warning(this,"ERROR","Correo invalido");
        ui->txtCorreo->clear();
        ui->txtCorreo->setFocus();


    }else if(!match_telefono.hasMatch()){
        QMessageBox::critical(this,"ERROR","Solo se pueden ingresar numeros");
        ui->txtCelular->clear();
        ui->txtCelular->setFocus();

    }else if(!match_digitos.hasMatch()){
        QMessageBox::warning(this,"ERROR","El numero de telefono no puede tener mas de 10 digitos");
        ui->txtCelular->clear();
        ui->txtCelular->setFocus();
    }else{

            QFile archivo_contactos("lista_contactos.txt");
            if (!archivo_contactos.open(QIODevice::Append|QIODevice::Text)){
                QMessageBox::warning(this,"ERROR","No se pudo abrir el archivo.");
                return;
            }
            contactos.push_back(c);
            QTextStream out(&archivo_contactos);
            out << c.nombre << "|"
                << c.apellido << "|"
                << c.celular << "|"
                << c.correo << "|"
                << c.direccion << "|"
                << c.nickname << "|"
                << c.cumpl << "\n";

                archivo_contactos.close();

            QMessageBox::information(this,"EXITO","Datos agregados correctamente");
            ui->txtNombre->clear();
            ui->txtNombre->setFocus();
            ui->txtApodo->clear();
            ui->txtCelular->clear();
            ui->txtCorreo->clear();
            ui->txtDireccion->clear();
            ui->txtApellido->clear();
            }



        }




void MainWindow::cargarContactos() {

    QFile archivo("lista_contactos.txt");

    if (!archivo.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "No se pudo abrir el archivo.");
        return;
    }
    contactos.clear();
    QTextStream in(&archivo);
    while (!in.atEnd()) {
        QString linea = in.readLine();
        if (linea.isEmpty()) continue;

        QStringList partes = linea.split("|");
        if (partes.size() < 7) continue;

        info_contactos nuevo;
        nuevo.nombre= partes[0];
        nuevo.apellido = partes[1];
        nuevo.celular = partes[2];
        nuevo.correo = partes[3];
        nuevo.direccion = partes[4];
        nuevo.nickname = partes[5];
        nuevo.cumpl = partes[6];

        contactos.push_back(nuevo);
    }

    archivo.close();

    //QMessageBox::information(this, "Éxito", "Contactos cargados correctamente.");
}




void MainWindow::on_actionMostrar_Contactos_triggered()
{

    mostrar_contactos *ventana = new mostrar_contactos(this);
    ventana->exec();

}




