#ifndef ACTUALIZAR_H
#define ACTUALIZAR_H

#include <QDialog>

namespace Ui {
class Actualizar;
}

class Actualizar : public QDialog
{
    Q_OBJECT

public:
    explicit Actualizar(QWidget *parent = nullptr);
    ~Actualizar();

private slots:
    void cargarContactos();
    void seleccionarContacto();
    void mostrarFormularioEdicion();
    void guardarCambios();
    void cancelarEdicion();
    void guardarContactos();

private:
    Ui::Actualizar *ui;
    int contactoActualIndex;
};

#endif // ACTUALIZAR_H
